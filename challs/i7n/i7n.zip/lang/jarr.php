<?php
$lang = array(
    "app_name" => "Brd app",
    "save" => "Keep",
    "cancel" => "Abandon Ship",
    "profile" => "Port Folio",
    "login" => "Sail In",
    "logout" => "Sail Out",
    "signup" => "Join the Crew",
    "timeline" => "Time Voyage",
    "display_name" => "Handle",
    "language"=> "Lingo",
    "bio"=> "Life Tale",
    "avatar" => "Sea Image",
    "choose_file" => "Choose a Chart",
    "preferences" => "Fancies",
    "theme" => "Color",
);
