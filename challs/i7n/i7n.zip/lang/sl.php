<?php
$lang = array(
    "app_name" => "Ptč Brd",
    "save" => "Shrani",
    "cancel" => "Prekliči",
    "profile" => "Profil",
    "login" => "Prijava",
    "logout" => "Odjava",
    "signup" => "Registracija",
    "timeline" => "Časovnica",
    "display_name" => "Prikazno ime",
    "language"=> "Jezik",
    "bio"=> "Biografija",
    "avatar" => "Avatar",
    "choose_file" => "Izberi datoteko",
    "preferences" => "Nastavitve",
    "theme" => "Tema",
);
