<?php
$lang = array(
    "app_name" => "Brd app",
    "save" => "Save",
    "cancel" => "Cancel",
    "profile" => "Profile",
    "login" => "Log in",
    "logout" => "Log out",
    "signup" => "Sign up",
    "timeline" => "Timeline",
    "display_name" => "Display name",
    "language"=> "Language",
    "bio"=> "Bio",
    "avatar" => "Avatar",
    "choose_file" => "Choose a file",
    "preferences" => "Preferences",
    "theme" => "Theme",
);