<?php
echo 'lol no.';